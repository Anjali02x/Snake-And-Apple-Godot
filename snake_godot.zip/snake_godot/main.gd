extends Node2D
# Snake & Apple - Godot 4.x
# Controls: swipe (phone) / arrow keys or WASD (PC). Tap top-right to mute.

const CELL := 24
const COLS := 20
const ROWS := 28
const BOARD_POS := Vector2(0, 110)
const SAVE_PATH := "user://save.cfg"

enum State { MENU, PLAYING, OVER }

var state := State.MENU
var snake: Array[Vector2i] = []
var dir := Vector2i.RIGHT
var next_dir := Vector2i.RIGHT
var apple := Vector2i.ZERO
var score := 0
var best := 0
var step_time := 0.16
var timer := 0.0
var t := 0.0
var over_at := 0.0
var muted := false
var swipe_start := Vector2.ZERO
var swiping := false
var mute_rect := Rect2(360, 20, 100, 44)
var font: Font

var music: AudioStreamPlayer
var sfx_eat: AudioStreamPlayer
var sfx_over: AudioStreamPlayer


func _ready() -> void:
	randomize()
	font = ThemeDB.fallback_font
	load_best()
	setup_audio()
	reset_game()


func setup_audio() -> void:
	var m: AudioStreamWAV = load("res://sounds/music.wav")
	m.loop_mode = AudioStreamWAV.LOOP_FORWARD
	m.loop_begin = 0
	m.loop_end = m.data.size() / 2  # 16-bit mono = 2 bytes per sample
	music = make_player(m, -10.0)
	sfx_eat = make_player(load("res://sounds/eat.wav"), 0.0)
	sfx_over = make_player(load("res://sounds/gameover.wav"), 0.0)
	music.play()


func make_player(stream: AudioStream, volume_db: float) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.stream = stream
	p.volume_db = volume_db
	add_child(p)
	return p


func play_sfx(p: AudioStreamPlayer) -> void:
	if not muted:
		p.play()


func toggle_mute() -> void:
	muted = not muted
	music.stream_paused = muted


func load_best() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) == OK:
		best = cfg.get_value("game", "best", 0)


func save_best() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("game", "best", best)
	cfg.save(SAVE_PATH)


func reset_game() -> void:
	snake = [Vector2i(10, 14), Vector2i(9, 14), Vector2i(8, 14)]
	dir = Vector2i.RIGHT
	next_dir = Vector2i.RIGHT
	score = 0
	step_time = 0.16
	timer = 0.0
	place_apple()


func start_game() -> void:
	if state == State.OVER and t - over_at < 0.6:
		return  # small delay so an accidental tap doesn't restart instantly
	reset_game()
	state = State.PLAYING


func place_apple() -> void:
	var open_cells: Array[Vector2i] = []
	for x in COLS:
		for y in ROWS:
			var c := Vector2i(x, y)
			if not snake.has(c):
				open_cells.append(c)
	if open_cells.is_empty():
		game_over()
		return
	apple = open_cells[randi() % open_cells.size()]


func game_over() -> void:
	state = State.OVER
	over_at = t
	if score > best:
		best = score
		save_best()
	play_sfx(sfx_over)


func _process(delta: float) -> void:
	t += delta
	if state == State.PLAYING:
		timer += delta
		if timer >= step_time:
			timer -= step_time
			step()
	queue_redraw()


func step() -> void:
	dir = next_dir
	var head := snake[0] + dir
	var ate := head == apple

	var body := snake.duplicate()
	if not ate:
		body.pop_back()  # tail moves away, so its cell is safe to enter

	var out := head.x < 0 or head.x >= COLS or head.y < 0 or head.y >= ROWS
	if out or body.has(head):
		game_over()
		return

	snake.push_front(head)
	if ate:
		score += 1
		step_time = max(0.07, step_time - 0.004)
		play_sfx(sfx_eat)
		place_apple()
	else:
		snake.pop_back()


func try_dir(d: Vector2i) -> void:
	if d + dir != Vector2i.ZERO:  # can't reverse into yourself
		next_dir = d


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if state != State.PLAYING:
			start_game()
			return
		match event.keycode:
			KEY_UP, KEY_W: try_dir(Vector2i.UP)
			KEY_DOWN, KEY_S: try_dir(Vector2i.DOWN)
			KEY_LEFT, KEY_A: try_dir(Vector2i.LEFT)
			KEY_RIGHT, KEY_D: try_dir(Vector2i.RIGHT)
			KEY_M: toggle_mute()

	elif event is InputEventScreenTouch:
		if event.pressed:
			if mute_rect.has_point(event.position):
				toggle_mute()
				return
			swipe_start = event.position
			swiping = true
			if state != State.PLAYING:
				start_game()
		else:
			swiping = false

	elif event is InputEventScreenDrag and swiping:
		var d: Vector2 = event.position - swipe_start
		if d.length() > 30.0:
			if abs(d.x) > abs(d.y):
				try_dir(Vector2i.RIGHT if d.x > 0 else Vector2i.LEFT)
			else:
				try_dir(Vector2i.DOWN if d.y > 0 else Vector2i.UP)
			swipe_start = event.position


# ---------------------------- drawing ----------------------------

func cell_center(c: Vector2i) -> Vector2:
	return BOARD_POS + Vector2(c) * CELL + Vector2(CELL, CELL) / 2.0


func center_text(text: String, y: float, size: int, color: Color) -> void:
	var w := font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	draw_string(font, Vector2((480.0 - w) / 2.0, y), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)


func _draw() -> void:
	# Background
	draw_rect(Rect2(0, 0, 480, 854), Color("1b2a41"))

	# Board (checkerboard grass)
	for x in COLS:
		for y in ROWS:
			var col := Color("a7d948") if (x + y) % 2 == 0 else Color("8ecc39")
			draw_rect(Rect2(BOARD_POS + Vector2(x, y) * CELL, Vector2(CELL, CELL)), col)

	# Apple (gently pulsing)
	var ap := cell_center(apple)
	var r := 9.5 + sin(t * 6.0) * 0.7
	draw_circle(ap + Vector2(0, 1), r, Color("e63946"))
	draw_circle(ap + Vector2(-3, -2), 2.5, Color(1, 1, 1, 0.5))
	draw_line(ap + Vector2(0, -8), ap + Vector2(1, -12), Color("5c3a21"), 2.0)
	draw_circle(ap + Vector2(4, -10), 3.0, Color("2a9d3f"))

	# Snake (tail to head)
	for i in range(snake.size() - 1, -1, -1):
		var p := cell_center(snake[i])
		var col := Color("2f6fed").lerp(Color("5b9bff"), 1.0 - float(i) / float(snake.size()))
		draw_circle(p, 10.5, col)
		if i < snake.size() - 1:
			draw_line(p, cell_center(snake[i + 1]), col, 21.0)

	# Eyes
	var hp := cell_center(snake[0])
	var d := Vector2(dir)
	var perp := Vector2(-d.y, d.x)
	for s in [-1.0, 1.0]:
		var e := hp + d * 4.0 + perp * 5.0 * s
		draw_circle(e, 3.5, Color.WHITE)
		draw_circle(e + d * 1.2, 1.7, Color.BLACK)

	# HUD
	draw_string(font, Vector2(20, 55), "Score: %d" % score, HORIZONTAL_ALIGNMENT_LEFT, -1, 32, Color.WHITE)
	draw_string(font, Vector2(20, 90), "Best: %d" % best, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color("ffd166"))
	draw_rect(mute_rect, Color("2c3e5c"))
	var label := "Sound OFF" if muted else "Sound ON"
	draw_string(font, Vector2(mute_rect.position.x + 12, mute_rect.position.y + 29), label,
		HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color.WHITE)
	center_text("Swipe to steer", 830, 16, Color("8d99ae"))

	# Overlays
	if state == State.MENU:
		draw_rect(Rect2(BOARD_POS, Vector2(COLS * CELL, ROWS * CELL)), Color(0, 0, 0, 0.55))
		center_text("SNAKE & APPLE", 400, 40, Color.WHITE)
		center_text("Swipe or use arrow keys", 450, 20, Color("cfd8e3"))
		center_text("Tap to start", 520, 28, Color("ffd166"))
	elif state == State.OVER:
		draw_rect(Rect2(BOARD_POS, Vector2(COLS * CELL, ROWS * CELL)), Color(0, 0, 0, 0.6))
		center_text("GAME OVER", 400, 44, Color("ff6b6b"))
		center_text("Score: %d" % score, 455, 26, Color.WHITE)
		if score > 0 and score == best:
			center_text("New best!", 495, 22, Color("ffd166"))
		center_text("Tap to play again", 560, 26, Color("ffd166"))
