import wave, struct, math

SR = 22050

def write(path, samples):
    peak = max(abs(s) for s in samples) or 1
    scale = 0.8 / peak
    w = wave.open(path, 'wb')
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes(b''.join(struct.pack('<h', int(s * scale * 32767)) for s in samples))
    w.close()

def osc(kind, phase):
    if kind == 'sine':
        return math.sin(phase)
    if kind == 'tri':
        return 2 / math.pi * math.asin(math.sin(phase))
    if kind == 'square':
        return 0.6 * (1 if math.sin(phase) >= 0 else -1)

def note(freq, dur, kind='sine', vol=0.5, decay=3.0, freq_end=None):
    n = int(SR * dur)
    out, phase = [], 0.0
    for i in range(n):
        t = i / SR
        f = freq if freq_end is None else freq + (freq_end - freq) * (t / dur)
        phase += 2 * math.pi * f / SR
        env = min(1.0, t / 0.015) * math.exp(-decay * t / dur) * min(1.0, (dur - t) / 0.02)
        out.append(osc(kind, phase) * env * vol)
    return out

def mix(a, b):
    n = max(len(a), len(b))
    a = a + [0.0] * (n - len(a)); b = b + [0.0] * (n - len(b))
    return [x + y for x, y in zip(a, b)]

# Eat sound: quick rising blip
eat = note(660, 0.07, 'square', 0.4, 1.0) + note(990, 0.12, 'square', 0.4, 2.5)
write('sounds/eat.wav', eat)

# Game over: descending tones
over = []
for f in (440, 349, 262, 196):
    over += note(f, 0.18, 'square', 0.4, 1.5)
over += note(130, 0.5, 'tri', 0.6, 3.0, freq_end=90)
write('sounds/gameover.wav', over)

# Background music: 8 s loop, 4 chords (C, Am, F, G), pentatonic melody
C5, D5, E5, G5, A5 = 523.25, 587.33, 659.25, 783.99, 880.0
melody = [E5, G5, A5, G5,  E5, G5, E5, D5,  C5, E5, G5, E5,  D5, E5, D5, C5]
bass = [130.81, 110.0, 87.31, 98.0]  # C3, A2, F2, G2

mel = []
for f in melody:
    mel += note(f, 0.5, 'tri', 0.35, 2.5)
bs = []
for f in bass:
    bs += note(f, 1.0, 'sine', 0.45, 1.2)
    bs += note(f * 2, 1.0, 'sine', 0.25, 1.8)
music = mix(mel, bs)
write('sounds/music.wav', music)
print("done")
